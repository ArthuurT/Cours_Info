void (*aff)(void *const);
err_t (*det)(void **);
