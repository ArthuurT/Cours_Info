#include <attributs_objet.h>
individu_t (*creer)(char * const, char * const);
char * nom ;
char * prenom ;
