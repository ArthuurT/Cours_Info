#include <ab_attributs.h>			        /*!< Herite des attributs d'un AB */
int (*comparer) ( const void * e1 , const void * e2) ;	/*!< Fonction de comparaison de 2 elements */
