#include <ab_animaux.h>

/*
 * Affichage 
 */


extern 
void ab_animaux_afficher( const ab_t * arbre , 
			  void (*fonction_affichage)(const void *)) 
{
  /***********
   * A FAIRE *
   ***********/
 
  return ; 
}

/*
 * Reconnaissance 
 */

extern 
void ab_animaux_reconnaitre( ab_t * arbre , 
			     err_t (*fonction_affectation)(void * , void *) ,
			     void (*fonction_affichage)(const void *)) 
{
  /***********
   * A FAIRE *
   ***********/

  return ; 
}
