#ifndef _MESSAGES_H_
#define _MESSAGES_H_

#define MESSAGES_TAILLE 2000
#define MESSAGES_NB 1000000
#define LU 1
#define NON_LU 0

/* Definition des types de base */

typedef enum booleen { FAUX , VRAI } booleen_t ;

#endif
