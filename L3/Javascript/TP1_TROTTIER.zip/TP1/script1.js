document.write("<p> Du texte écrit en JS </p>")
alert("Hello world ! en JS")
